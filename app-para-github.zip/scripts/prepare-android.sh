#!/usr/bin/env bash
# Roda depois de "npx cap add android": AdMob App ID, versão e assinatura
set -euo pipefail
M=android/app/src/main/AndroidManifest.xml
APPID="${ADMOB_APP_ID:-ca-app-pub-3940256099942544~3347511713}"   # padrão = ID de TESTE do Google
if ! grep -q "com.google.android.gms.ads.APPLICATION_ID" "$M"; then
  sed -i "s#</application>#    <meta-data android:name=\"com.google.android.gms.ads.APPLICATION_ID\" android:value=\"$APPID\"/>\n    </application>#" "$M"
fi
G=android/app/build.gradle
VC="${VERSION_CODE:-1}"; VN="${VERSION_NAME:-1.0.0}"
sed -i "s/versionCode [0-9]\+/versionCode $VC/; s/versionName \"[^\"]*\"/versionName \"$VN\"/" "$G"
if [ -n "${KEYSTORE_B64:-}" ]; then
  echo "$KEYSTORE_B64" | base64 -d > android/app/release.keystore
  cat >> "$G" <<GRADLE

android {
  signingConfigs { release {
    storeFile file('release.keystore'); storePassword System.getenv('KEYSTORE_PASSWORD')
    keyAlias System.getenv('KEY_ALIAS'); keyPassword System.getenv('KEY_PASSWORD') } }
  buildTypes { release { signingConfig signingConfigs.release; minifyEnabled false } }
}
GRADLE
fi
