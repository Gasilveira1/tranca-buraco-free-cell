// Prepara o index.html para a versão de loja: DEMO=false (sem compras/indicações simuladas)
import fs from 'node:fs';
const f = 'www/index.html';
let s = fs.readFileSync(f, 'utf8');
if (!/const DEMO=true;/.test(s)) { console.log('DEMO já estava false (ou não encontrado)'); }
s = s.replace('const DEMO=true;', 'const DEMO=false;');
// IDs reais do AdMob (defina como variáveis no GitHub Actions: ADMOB_BANNER, ADMOB_INTER, ADMOB_REWARD)
const rep = (test, real) => { if (real) s = s.split(test).join(real); };
rep('ca-app-pub-3940256099942544/6300978111', process.env.ADMOB_BANNER);
rep('ca-app-pub-3940256099942544/1033173712', process.env.ADMOB_INTER);
rep('ca-app-pub-3940256099942544/5224354917', process.env.ADMOB_REWARD);
if (process.env.ADMOB_BANNER) s = s.split('isTesting:true').join('isTesting:false');
// Ranking online: URL do Cloudflare Worker (secret RANK_URL no GitHub). Vazio = ranking desligado.
if (process.env.RANK_URL) s = s.replace("const RANK_URL='';", "const RANK_URL='" + process.env.RANK_URL.replace(/'/g, '') + "';");
// Fase Fundador (lançamento): último dia no formato AAAA-MM-DD (secret FOUNDER_END). Sem secret = 31/03/2027.
if (process.env.FOUNDER_END && /^\d{4}-\d{2}-\d{2}$/.test(process.env.FOUNDER_END)) s = s.replace("const FOUNDER_END='2027-03-31';", "const FOUNDER_END='" + process.env.FOUNDER_END + "';");
fs.writeFileSync(f, s);
console.log('www/index.html pronto para loja. AdMob real:', !!process.env.ADMOB_BANNER);
